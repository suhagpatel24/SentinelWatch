# Detection rules

| Rule | Default severity | Meaning / validation |
|---|---:|---|
| Denylisted process | HIGH | Exact process name appears in configured denylist; verify file path and publisher. |
| Unknown process | LOW | Name is not in allowlist; commonly produces benign findings until tuned. |
| Suspicious parent-child | HIGH | Office application launches shell/script host; inspect user activity and command line. |
| User-writable process path | MEDIUM | Process path includes configured Temp/Downloads fragments. |
| New service | HIGH | Service name absent from first-run baseline; verify installation/change history. |
| Suspicious service path | HIGH | Service image path contains configured writable path fragment. |
| Unquoted service path | MEDIUM | Path contains spaces and is not quoted; manually inspect exact ImagePath and ACLs. |
| Suspicious startup entry | MEDIUM | Run/RunOnce command references a configured writable path. |

Severity is a triage priority, not a certainty score. Tune allowlists and path fragments for the host.
