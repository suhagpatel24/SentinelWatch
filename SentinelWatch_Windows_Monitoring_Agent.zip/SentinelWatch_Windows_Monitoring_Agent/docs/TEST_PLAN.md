# Safe validation plan

1. Run the agent once on a trusted Windows machine. Confirm process and service inventories are populated.
2. Confirm first-run `reports/service_baseline.json` is created after a successful service collection.
3. Run a second scan. Confirm unchanged services do not trigger NEW_SERVICE.
4. Review `config/settings.json`; add a deliberately nonexistent process name to `denylist_process_names` only to validate the rule logic with a harmless test process name if you can safely create a matching benign test executable. Remove it after testing.
5. Review `reports/latest_report.json`, `events.jsonl`, and both CSV files.
6. Open the dashboard and click Run scan now. Confirm counts and alerts update.
7. Do not create a real malicious service, exploit service permissions, inject into processes, or disable security software for demonstration.

For a classroom demo, show the inventory, a configured rule in settings, the resulting alert record, and the report/dashboard. Do not present a heuristic alert as proof of compromise.
