# Architecture

```text
                 +-----------------------+
                 |      monitor.py       |
                 | scan scheduler/runner |
                 +-----------+-----------+
                             |
          +------------------+------------------+
          |                  |                  |
+---------v---------+ +------v---------+ +------v----------+
| process_monitor   | | service_auditor| | startup_auditor |
| psutil PID / PPID | | PowerShell CIM | | Run / RunOnce   |
+---------+---------+ +-------+--------+ +--------+--------+
          +------------------+-------------------+
                             |
                    +--------v--------+
                    |    detector     |
                    | rule evaluation |
                    +--------+--------+
                             |
                    +--------v--------+
                    |    reporter     |
                    | JSON/CSV/JSONL  |
                    +--------+--------+
                             |
                    +--------v--------+
                    | reports/ + Flask|
                    | local dashboard |
                    +-----------------+
```

All collectors are read-only. `monitor.py` coordinates collection, detection, and report writing. Flask only displays the latest report and can request a new scan.
