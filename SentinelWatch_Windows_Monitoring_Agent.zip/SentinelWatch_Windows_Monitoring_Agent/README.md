# SentinelWatch — Windows Service & Process Monitoring Agent

A modular, defensive, read-only Windows monitoring prototype.

## Project layout
- `monitor.py`: orchestration and continuous scan loop
- `app.py`: local Flask dashboard (`127.0.0.1:5050`)
- `modules/process_monitor.py`: PID/PPID, process path, user and process lineage
- `modules/service_auditor.py`: Windows service inventory using PowerShell CIM
- `modules/startup_auditor.py`: common Run/RunOnce startup registry entries
- `modules/detector.py`: rule engine and severity assignment
- `modules/reporter.py`: JSON, JSONL and CSV output
- `core/`: shared configuration and utility functions
- `config/settings.json`: allowlist, denylist, suspicious chains and path rules
- `reports/`: generated reports and baseline
- `docs/`: architecture, detection rules and test plan

## Install on Windows 10/11
1. Extract this ZIP to a folder such as `C:\SentinelWatch`.
2. Open PowerShell in that folder.
3. Create and activate a virtual environment:
   ```powershell
   py -3 -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```
   If activation is blocked, use Command Prompt: `.venv\Scripts\activate.bat`.
4. Install:
   ```powershell
   python -m pip install -r requirements.txt
   ```
5. Run monitoring:
   ```powershell
   python monitor.py
   ```
   Stop with Ctrl+C. Run as Administrator for fuller visibility.
6. Optional dashboard in a second terminal:
   ```powershell
   python app.py
   ```
   Open `http://127.0.0.1:5050`.

## Output
- `reports/latest_report.json`: latest full scan
- `reports/events.jsonl`: appended alert events
- `reports/process_inventory.csv`: process inventory
- `reports/service_inventory.csv`: service inventory
- `reports/service_baseline.json`: service names captured on first successful service scan

## Baseline and configuration
The first successful service scan creates a baseline. Check that it represents a trusted state before treating future new-service alerts as meaningful. Edit `config/settings.json` to customize allowlisted process names, denylisted names, suspicious parent-child rules, path fragments, and scan interval. Unknown process names are LOW severity by default; many legitimate applications will be unknown until you customize the allowlist.

## Limitations
- This is an educational project, not antivirus/EDR.
- Process executable signature validation and robust service ACL/permission analysis are not implemented in this version.
- Process injection detection is not implemented; a process tree heuristic cannot prove injection.
- Service path checks and unquoted-path heuristics need manual validation.
- The startup audit covers common Run/RunOnce registry keys, not every Windows persistence mechanism or scheduled task.
- Some process metadata may be unavailable without elevation.
- No process termination, service changes, registry edits, or remote monitoring are performed.
- Use only on devices you own or are authorized to monitor.
