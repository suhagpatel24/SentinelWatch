"""Orchestrates process, service, startup collection and rule evaluation."""
import json, platform, time
from core.config import ROOT, load_settings
from core.utils import timestamp
from modules.process_monitor import collect_processes
from modules.service_auditor import collect_services
from modules.startup_auditor import collect_startup_entries
from modules.detector import detect, event
from modules.reporter import write_reports

def scan_once():
    settings=load_settings()
    processes=collect_processes()
    services, service_warning=collect_services()
    startup, startup_warning=collect_startup_entries()
    baseline_path=ROOT/settings["baseline_services_file"]
    baseline=None
    if baseline_path.exists():
        try: baseline=json.loads(baseline_path.read_text(encoding="utf-8"))
        except (OSError,json.JSONDecodeError): baseline=None
    alerts=detect(processes,services,startup,settings,baseline)
    if baseline is None and services:
        baseline_path.parent.mkdir(parents=True,exist_ok=True)
        baseline_path.write_text(json.dumps(sorted(s["name"] for s in services),indent=2),encoding="utf-8")
        alerts.append(event("INFO","BASELINE_CREATED","Created first-run service baseline. Review the baseline before relying on new-service alerts."))
    warnings=[x for x in [service_warning,startup_warning] if x]
    report={"generated_at":timestamp(),"hostname":platform.node(),"platform":platform.platform(),
      "summary":{"process_count":len(processes),"service_count":len(services),
       "startup_entry_count":len(startup),"alert_count":len(alerts),
       "high":sum(a["severity"]=="HIGH" for a in alerts),
       "medium":sum(a["severity"]=="MEDIUM" for a in alerts),
       "low":sum(a["severity"]=="LOW" for a in alerts)},
      "processes":processes,"services":services,"startup_entries":startup,
      "alerts":alerts,"collection_warnings":warnings}
    write_reports(report,ROOT,settings)
    return report

def main():
    settings=load_settings()
    interval=max(5,int(settings.get("scan_interval_seconds",10)))
    print("SentinelWatch monitoring agent started. Press Ctrl+C to stop.")
    print("For best visibility, run this terminal as Administrator.")
    while True:
        try:
            r=scan_once(); s=r["summary"]
            print(f"[{r['generated_at']}] processes={s['process_count']} services={s['service_count']} startup={s['startup_entry_count']} alerts={s['alert_count']} (HIGH {s['high']}, MEDIUM {s['medium']}, LOW {s['low']})")
            for warning in r["collection_warnings"]: print("WARNING:",warning)
            time.sleep(interval)
        except KeyboardInterrupt:
            print("\nMonitoring stopped."); break
        except Exception as exc:
            print("Scan error:",exc); time.sleep(interval)

if __name__=="__main__": main()
