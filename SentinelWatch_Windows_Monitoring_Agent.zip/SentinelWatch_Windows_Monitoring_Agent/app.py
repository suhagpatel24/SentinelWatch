"""Local-only Flask dashboard. Does not expose the monitoring agent to the network."""
import json
from flask import Flask, render_template, redirect, url_for
from core.config import ROOT, load_settings
from monitor import scan_once
app=Flask(__name__)
app.secret_key="sentinelwatch-local-dashboard"
def latest():
    p=ROOT/load_settings()["latest_report_file"]
    try: return json.loads(p.read_text(encoding="utf-8"))
    except (OSError,json.JSONDecodeError): return None
@app.get("/")
def dashboard(): return render_template("dashboard.html",report=latest())
@app.post("/scan")
def scan(): scan_once(); return redirect(url_for("dashboard"))
@app.get("/api/report")
def api_report(): return latest() or {"message":"No report yet. Run a scan."}
if __name__=="__main__": app.run(host="127.0.0.1",port=5050,debug=False)
