"""Read-only Windows service inventory via PowerShell CIM."""
import json, platform, subprocess

def collect_services():
    if platform.system() != "Windows":
        return [], "Windows service inventory requires Windows."
    script = r"""
    Get-CimInstance Win32_Service | Select-Object Name,DisplayName,State,StartMode,StartName,PathName,ProcessId |
    ConvertTo-Json -Depth 3 -Compress
    """
    try:
        cp = subprocess.run(["powershell.exe","-NoProfile","-NonInteractive","-Command",script],
                            capture_output=True,text=True,timeout=30)
        if cp.returncode and not cp.stdout.strip():
            return [], cp.stderr.strip() or "PowerShell service query failed."
        data = json.loads(cp.stdout) if cp.stdout.strip() else []
        if isinstance(data, dict): data = [data]
        return [{"name":x.get("Name",""),"display_name":x.get("DisplayName",""),
                 "state":x.get("State",""),"start_mode":x.get("StartMode",""),
                 "account":x.get("StartName",""),"path":x.get("PathName",""),
                 "pid":x.get("ProcessId",0)} for x in data], ""
    except Exception as exc:
        return [], f"Service collection failed: {exc}"
