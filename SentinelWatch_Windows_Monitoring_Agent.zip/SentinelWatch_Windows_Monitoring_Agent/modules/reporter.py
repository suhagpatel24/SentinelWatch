"""Write JSON, JSONL, and CSV reports."""
import csv, json
from pathlib import Path

def write_reports(report, root, settings):
    report_path=root/settings["latest_report_file"]
    report_path.parent.mkdir(parents=True,exist_ok=True)
    report_path.write_text(json.dumps(report,indent=2),encoding="utf-8")
    events_path=root/settings["events_file"]
    with events_path.open("a",encoding="utf-8") as f:
        for item in report["alerts"]: f.write(json.dumps(item)+"\\n")
    csv_path=root/"reports"/"process_inventory.csv"
    fields=["pid","ppid","parent_name","name","path","username","started","command_line"]
    with csv_path.open("w",newline="",encoding="utf-8-sig") as f:
        writer=csv.DictWriter(f,fieldnames=fields); writer.writeheader(); writer.writerows(report["processes"])
    service_csv=root/"reports"/"service_inventory.csv"
    sf=["name","display_name","state","start_mode","account","path","pid"]
    with service_csv.open("w",newline="",encoding="utf-8-sig") as f:
        writer=csv.DictWriter(f,fieldnames=sf); writer.writeheader(); writer.writerows(report["services"])
    return report_path
