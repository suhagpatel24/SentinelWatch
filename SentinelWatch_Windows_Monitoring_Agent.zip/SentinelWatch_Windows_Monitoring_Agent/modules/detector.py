"""Rule-based detection; alerts are leads for manual validation, not malware verdicts."""
from core.utils import norm, timestamp

def event(severity, category, message, details=None):
    return {"timestamp":timestamp(),"severity":severity,"category":category,
            "message":message,"details":details or {}}

def detect(processes, services, startup, settings, baseline):
    alerts=[]
    allow={norm(x) for x in settings.get("allowlist_process_names",[])}
    deny={norm(x) for x in settings.get("denylist_process_names",[])}
    chains={norm(k):{norm(v) for v in vals} for k,vals in settings.get("suspicious_parent_child",{}).items()}
    fragments=[norm(x).replace("/","\\") for x in settings.get("suspicious_path_fragments",[])]
    by_pid={p["pid"]:p for p in processes}
    for p in processes:
        name=norm(p["name"]); path=norm(p.get("path")).replace("/","\\")
        if name in deny:
            alerts.append(event("HIGH","DENYLIST_PROCESS",f"Denylisted process running: {p['name']}",p))
        elif name not in allow:
            alerts.append(event("LOW","UNKNOWN_PROCESS",f"Process not in configured allowlist: {p['name']}",p))
        if path and any(f in path for f in fragments):
            alerts.append(event("MEDIUM","USER_WRITABLE_PATH",f"Process launched from a monitored writable path: {p['name']}",p))
        parent=by_pid.get(p.get("ppid"))
        if parent and norm(parent["name"]) in chains and name in chains[norm(parent["name"])]:
            alerts.append(event("HIGH","SUSPICIOUS_PARENT_CHILD",
                f"Suspicious chain: {parent['name']} (PID {parent['pid']}) -> {p['name']} (PID {p['pid']})",
                {"parent":parent,"child":p}))
    known={norm(x) for x in (baseline or [])}
    for s in services:
        if known and norm(s["name"]) not in known:
            alerts.append(event("HIGH","NEW_SERVICE",f"Service not present in trusted baseline: {s['name']}",s))
        path=norm(s.get("path")).replace("/","\\")
        if path and any(f in path for f in fragments):
            alerts.append(event("HIGH","SUSPICIOUS_SERVICE_PATH",f"Service path includes a monitored writable location: {s['name']}",s))
        if s.get("path") and " " in s["path"] and not s["path"].lstrip().startswith('"'):
            alerts.append(event("MEDIUM","UNQUOTED_SERVICE_PATH",
                f"Service command path contains spaces and is not quoted; verify manually: {s['name']}",s))
    for entry in startup:
        command=norm(entry.get("command")).replace("/","\\")
        if any(f in command for f in fragments):
            alerts.append(event("MEDIUM","SUSPICIOUS_STARTUP_ENTRY",
                f"Startup entry references a monitored writable location: {entry.get('name')}",entry))
    return alerts
