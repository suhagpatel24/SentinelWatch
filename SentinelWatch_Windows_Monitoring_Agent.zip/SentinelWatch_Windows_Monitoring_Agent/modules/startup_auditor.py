"""Audit common Run/RunOnce registry startup entries without changing them."""
import json, platform, subprocess

def collect_startup_entries():
    if platform.system() != "Windows":
        return [], "Startup registry audit requires Windows."
    script = r"""
    $ErrorActionPreference='SilentlyContinue'
    $keys=@('HKLM:\Software\Microsoft\Windows\CurrentVersion\Run',
    'HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce',
    'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run',
    'HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce')
    $out=@()
    foreach($key in $keys){ if(Test-Path $key){$obj=Get-ItemProperty $key
      foreach($p in $obj.PSObject.Properties){if($p.Name -notmatch '^PS'){
        $out += [pscustomobject]@{registry_key=$key;name=$p.Name;command=[string]$p.Value}
      }}
    }}
    $out | ConvertTo-Json -Depth 3 -Compress
    """
    try:
        cp=subprocess.run(["powershell.exe","-NoProfile","-NonInteractive","-Command",script],
                          capture_output=True,text=True,timeout=20)
        data=json.loads(cp.stdout) if cp.stdout.strip() else []
        return (data if isinstance(data,list) else [data]), ""
    except Exception as exc:
        return [], f"Startup registry collection failed: {exc}"
