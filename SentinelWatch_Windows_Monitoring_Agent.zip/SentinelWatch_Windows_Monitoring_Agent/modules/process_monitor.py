"""Collect process metadata and parent-child relationships (read-only)."""
import psutil
from datetime import datetime
from core.utils import norm

def collect_processes():
    items, by_pid = [], {}
    for proc in psutil.process_iter(["pid","ppid","name","exe","username","cmdline","create_time"]):
        try:
            d = proc.info
            item = {
                "pid": d.get("pid"), "ppid": d.get("ppid"),
                "name": d.get("name") or "unknown",
                "path": d.get("exe") or "",
                "username": d.get("username") or "",
                "command_line": " ".join(d.get("cmdline") or [])[:600],
                "started": datetime.fromtimestamp(d["create_time"]).astimezone().isoformat(timespec="seconds") if d.get("create_time") else ""
            }
            items.append(item)
            by_pid[item["pid"]] = item
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess, OSError):
            continue
    for item in items:
        parent = by_pid.get(item["ppid"])
        item["parent_name"] = parent["name"] if parent else "unavailable"
    return items
