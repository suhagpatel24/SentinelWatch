import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SETTINGS_PATH = ROOT / "config" / "settings.json"
def load_settings():
    return json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
