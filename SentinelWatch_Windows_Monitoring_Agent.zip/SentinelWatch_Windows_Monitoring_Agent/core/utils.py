from datetime import datetime, timezone
def timestamp():
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")
def norm(value):
    return (value or "").strip().lower()
